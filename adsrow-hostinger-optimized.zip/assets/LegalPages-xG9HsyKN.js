import{j as e,r as m,L as y}from"./index-B0L3cNBV.js";const p=[["1. Acceptance of these Terms",`1.1 These Terms of Service ("Terms") govern your use of the website at [domain] ("Website"), our WhatsApp business account, and all advertising services provided by Adsrow Media Network Private Limited ("Adsrow", "we", "us", "our").

1.2 By browsing the Website, contacting us, confirming a booking or making a payment, you ("Advertiser", "you", "your") agree to these Terms, our Refund & Cancellation Policy and our Privacy Policy (together, the "Agreement"). If you do not agree, do not use our services.

1.3 If you accept these Terms on behalf of a business, you confirm that you are authorised to bind that business.`],["2. Definitions",`2.1 Capitalised terms not defined in these Terms (including "Campaign", "Advertisement", "Creative", "Plan", "Booking Confirmation", "Start Date", "Committed Plan", "Contracted Plays", "Proof-of-Play Report" and "Working Day") have the meanings given in our Refund & Cancellation Policy.

2.2 "Network" means the digital screens operated or managed by Adsrow at partner venues, including residential communities, restaurants and cafés, fitness centres and commercial spaces.

2.3 "Venue Partner" means the owner, occupier or association of a property where a Network screen is installed.

2.4 "Audience Estimate" means any figure describing people reached, footfall, plays or views that Adsrow shares for planning purposes.`],["3. Our services",`3.1 Adsrow sells advertising time on the Network. Advertisements play in a scheduled loop, in slots of up to 10 seconds, at the venues and for the period set out in your Booking Confirmation.

3.2 Adsrow may also provide optional services, including creative design, video production, category exclusivity and additional frequency ("Add-ons"), on the terms stated when you book them.

3.3 Adsrow may change, add or withdraw Plans, venues or features for future bookings. Changes will not reduce what was confirmed in an existing Booking Confirmation, except as permitted by Clauses 11 and 21.`],["4. Eligibility",`4.1 Our services are intended for businesses, professionals and organisations. You must be at least 18 years old and legally able to enter into a binding contract under the Indian Contract Act, 1872.

4.2 You must provide accurate details, including your business name, contact information and, where applicable, your GSTIN. You are responsible for keeping these details up to date.`],["5. Bookings",`5.1 Bookings may be made through the Website, WhatsApp, email, phone or in person. A booking is binding only when Adsrow issues a Booking Confirmation and receives payment as set out in Clause 6.

5.2 Prices, discounts and Plan details shown on the Website or in chat are invitations to book, not binding offers. They are subject to screen availability at the time of booking.

5.3 Adsrow may decline any booking at its discretion, including where inventory is unavailable, the business category conflicts with a venue's rules or an existing category exclusivity, or the Advertisement does not meet Clause 8.`],["6. Prices, payment and taxes",`6.1 All prices are in Indian Rupees and exclusive of GST and other applicable taxes, which will be charged additionally.

6.2 Plans are billed monthly in advance. Payments must be made through the secure payment link, subscription link or bank details provided by Adsrow. Adsrow does not collect or store your card details, UPI PIN or banking passwords.

6.3 For Committed Plans, you authorise Adsrow and its payment service provider to collect recurring instalments through UPI AutoPay, e-mandate or standing instruction, in line with the Reserve Bank of India's rules on recurring payments.

6.4 If a payment is not received by its due date, Adsrow may pause or end the Campaign as set out in the Refund & Cancellation Policy.

6.5 Adsrow will issue GST-compliant tax invoices. If you are entitled to deduct tax at source, you must provide the TDS certificate within the statutory time limit.`],["7. Your Advertisement and your responsibilities",`7.1 You are solely responsible for the content of every Advertisement you supply or approve, including all claims, offers, prices, images, music, logos, trademarks and contact details in it.

7.2 You confirm, and continue to confirm throughout the Campaign, that:
(a) you own, or have obtained all licences, permissions and consents needed for, every element of the Advertisement, including any music, fonts, images and the likeness of any person shown;
(b) all claims are true, can be substantiated, and are not misleading;
(c) the Advertisement complies with all applicable laws, including the Consumer Protection Act, 2019, the Advertising Standards Council of India (ASCI) Code, and any law specific to your industry; and
(d) you hold any registration that the law requires you to display, such as a RERA registration number for real estate projects, or a licence or registration number for regulated professions and financial products.

7.3 Advertisements must meet Adsrow's technical specifications: [9:16 vertical, 1080 × 1920 pixels, up to 10 seconds, image or video, no audio dependence], unless agreed otherwise.`],["8. Content standards and review",`8.1 Network screens are placed in family and community spaces. Every Advertisement is reviewed before display, and Adsrow's decision on suitability is final, made reasonably and in good faith.

8.2 Adsrow will not display Advertisements that promote or contain:
(a) tobacco, alcohol, or any surrogate or brand-extension advertising for them;
(b) betting, gambling or real-money gaming, except where clearly permitted by law and accepted by Adsrow in writing;
(c) drugs, remedies or treatments with claims prohibited under the Drugs and Magic Remedies (Objectionable Advertisements) Act, 1954, or other unsubstantiated health or cure claims;
(d) sexually suggestive, obscene, violent or frightening content;
(e) content that is defamatory, hateful, or offensive to any religion, caste, community, gender or group;
(f) political or election advertising, unless Adsrow agrees in writing and all legal pre-certification requirements are met;
(g) attacks on, or disparaging comparisons with, named competitors;
(h) guaranteed financial returns, unregistered investment schemes or other content prohibited by SEBI or RBI rules; or
(i) any content that violates law, a court order, or a Venue Partner's written rules.

8.3 A Venue Partner may ask that a particular Advertisement or business category not be shown at its venue. Adsrow will move your Advertisement to a comparable venue in that case.

8.4 Adsrow may remove an Advertisement at any time if it receives a complaint, legal notice or regulatory direction about it, or reasonably believes it breaches this Clause 8. Refunds in such cases are governed by the Refund & Cancellation Policy.`],["9. Licence to Adsrow",`9.1 You grant Adsrow a non-exclusive, royalty-free licence, for the duration of the Campaign, to copy, format, resize, schedule and display the Advertisement on the Network, and to make the technical adjustments needed for display.

9.2 You also permit Adsrow to photograph or film the Advertisement playing on Network screens, and to use those images to provide proof of display and in Adsrow's own portfolio and marketing. You may opt out of portfolio and marketing use by writing to us before the Start Date.`],["10. Creative produced by Adsrow",`10.1 Where Adsrow designs or produces a Creative for you, Adsrow will share a draft for approval. The Plan or Add-on includes [two] rounds of revisions; further revisions may be charged.

10.2 Once you have paid in full, you own the final approved Creative and may use it elsewhere. Adsrow keeps ownership of its templates, layouts, working files, stock licences and know-how, and of any unapproved drafts.

10.3 Stock images, music or fonts used under Adsrow's licences may only be used on the Network unless you obtain your own licence for other use.

10.4 You remain responsible for the accuracy of the information, offers and claims you provide for the Creative, and for checking the final Creative before approval.`],["11. Delivery, scheduling and placement",`11.1 Adsrow will display the Advertisement at the venues, frequency and duration set out in the Booking Confirmation. The position of the Advertisement within the loop, and the exact time it plays, may vary.

11.2 Audience Estimates are good-faith estimates based on venue information and Adsrow's own data. They are provided for planning only and are not a guarantee of the number of people who will see the Advertisement, or of any sales, enquiries or other business results.

11.3 Adsrow may, acting reasonably, replace a venue or screen with one of comparable audience and category, for example where a screen is faulty, relocated or withdrawn by a Venue Partner.

11.4 Adsrow's delivery commitment, and your remedies for any shortfall in Contracted Plays, are set out in the Refund & Cancellation Policy.`],["12. Reporting",`12.1 Adsrow will provide Proof-of-Play Reports and, where available, photographs of the Advertisement on screen and QR-code scan counts.

12.2 QR scan counts and similar metrics are measured by Adsrow's systems or third-party tools and may contain minor discrepancies. Adsrow's records will be treated as accurate unless you show a clear error.`],["13. Add-ons and category exclusivity",`13.1 Where you book category exclusivity, Adsrow will not display Advertisements from a directly competing business in the same category, at the same venues, during your Campaign. The category will be described in the Booking Confirmation.

13.2 Category exclusivity does not apply to a Venue Partner's own content, or to brands of a different category that also offer a related product.`],["14. Venues and screens",`14.1 Network screens are installed at Venue Partners' premises under separate agreements. You have no right to access, operate or alter any screen or venue.

14.2 During your Campaign and for [six] months after it ends, you agree not to approach Adsrow's Venue Partners to install, or have a third party install, competing advertising screens using information obtained through Adsrow. This Clause does not stop you from doing ordinary business with any venue.`],["15. Communications",`15.1 By contacting Adsrow on WhatsApp, by phone or by email, or by booking a Plan, you agree that Adsrow may contact you on those channels about your enquiry, booking, payments, Campaign updates, reports and renewals.

15.2 Adsrow will send promotional messages only with your consent. You can stop promotional messages at any time by replying STOP on WhatsApp or using the unsubscribe link in an email. Service messages about an active booking will continue.

15.3 Communications on WhatsApp are also subject to WhatsApp's own terms and privacy policy.`],["16. Confidentiality",`16.1 Each party will keep confidential any non-public information received from the other, including pricing, venue details, campaign data and business plans, and will use it only for the purposes of this Agreement.

16.2 This obligation does not apply to information that is public, was already known to the receiving party, is independently developed, or must be disclosed by law or by order of an authority.`],["17. Indemnity","You will indemnify and hold harmless Adsrow, its directors, employees and Venue Partners against any claim, penalty, loss, damage or reasonable legal cost arising from: (a) the content of your Advertisement, including any infringement of third-party rights or any misleading claim; (b) your breach of these Terms or of any law; or (c) any claim by your customers relating to your products or services."],["18. Limitation of liability",`18.1 Adsrow's total liability arising out of or in connection with any Campaign, whether in contract, tort (including negligence) or otherwise, will not exceed the fees you actually paid to Adsrow for that Campaign in the three months before the event giving rise to the claim.

18.2 Adsrow will not be liable for any indirect or consequential loss, or for loss of profits, revenue, business, goodwill or anticipated savings.

18.3 Nothing in these Terms limits liability that cannot be limited under applicable law, including liability for fraud.`],["19. Disclaimers",`19.1 Except as expressly stated in the Agreement, Adsrow provides its services "as is" and makes no warranty that any Campaign will produce particular results.

19.2 The Website may contain links to third-party websites, including WhatsApp and payment providers. Adsrow is not responsible for their content or practices.`],["20. Suspension and termination",`20.1 Adsrow may suspend or end a Campaign, with written notice, if you: (a) fail to pay any amount when due; (b) breach Clause 7 or Clause 8; (c) breach any other term and do not fix it within 7 days of notice; or (d) become insolvent or stop carrying on business.

20.2 Either party may end the Agreement as permitted in the Refund & Cancellation Policy.

20.3 Clauses 7, 9.2, 10, 14.2, 16, 17, 18, 22 and 25 survive the end of the Agreement.`],["21. Force majeure","Neither party is liable for failure or delay caused by events beyond its reasonable control. The consequences for a Campaign, including extensions, credits and refunds, are set out in the Refund & Cancellation Policy."],["22. Governing law and dispute resolution",`22.1 The Agreement is governed by the laws of India.

22.2 The parties will first try to resolve any dispute through good-faith discussion for 30 days, starting from written notice of the dispute.

22.3 Any dispute not resolved in that time will be referred to arbitration by a sole arbitrator appointed by mutual agreement, under the Arbitration and Conciliation Act, 1996. The seat and venue of arbitration will be Vijayawada, Andhra Pradesh, and proceedings will be in English.

22.4 Subject to Clause 22.3, the courts at Vijayawada will have exclusive jurisdiction, including for interim relief.

22.5 Nothing in this Clause limits any right you may have as a consumer under the Consumer Protection Act, 2019, including the right to approach a Consumer Commission with appropriate jurisdiction.`],["23. Grievance redressal","Complaints about our services or the Website may be sent to our Grievance Officer, whose details are in Clause 15 of the Refund & Cancellation Policy and on the Website. Complaints will be acknowledged within 48 hours and resolved within one month of receipt."],["24. Changes to these Terms",'Adsrow may update these Terms from time to time. The updated Terms will be published on the Website with a revised "Last updated" date. Changes will not apply to bookings confirmed before the change, unless you agree otherwise.'],["25. General",`25.1 Entire agreement: the Agreement, together with each Booking Confirmation, is the entire agreement between the parties for each Campaign. If they conflict, the Booking Confirmation prevails for that Campaign, then the Refund & Cancellation Policy, then these Terms.

25.2 Relationship: the parties are independent contractors. Nothing in the Agreement creates a partnership, agency or employment relationship.

25.3 Assignment: you may not transfer the Agreement without Adsrow's written consent. Adsrow may transfer it to an affiliate or a successor of its business.

25.4 Notices: notices may be sent by WhatsApp to Adsrow's verified business account or the number you used to book, or by email to the addresses each party has provided. A notice is received when sent, if sent on a Working Day before 6 PM; otherwise on the next Working Day.

25.5 Electronic acceptance: a booking confirmed on WhatsApp or by email, and payment through Adsrow's link, are valid acceptance under the Information Technology Act, 2000.

25.6 Waiver and severability: a failure to enforce any term is not a waiver of it. If any term is held invalid, the rest of the Agreement continues in full force.`],["26. Contact","Adsrow Media Network Private Limited, [registered office address], Vijayawada, Andhra Pradesh · WhatsApp: +91 83746 22055 · Email: [support email]"],["Drafting notes (remove before publishing)",`Clause 7.3: confirm the technical specs match what your screens and CMS (content management system) actually use.

Clause 10.1: set the number of free revision rounds, and confirm whether design is included free with any Plan.

Clause 14.2: a non-solicitation clause must be reasonable to be enforceable under Section 27 of the Indian Contract Act. Keep it narrow, as drafted, and confirm it with your advocate.

Clause 18.1: the liability cap is the main protection for a small media business. Keep it unless a large client negotiates a different figure in a signed agreement.

Clause 22.3: arbitration suits business clients. Consumers keep their right to go to a Consumer Commission (Clause 22.5).

Venue Partners need their own agreement (installation, revenue share, power, removal). These Terms cover advertisers only.

Fill in all [square bracket] items and have an Indian advocate review the final text.`]],f=[["1. Introduction and scope",`1.1 This Refund & Cancellation Policy ("Policy") governs cancellations, refunds, credits and make-goods for all advertising services provided by Adsrow Media Network Private Limited ("Adsrow", "we", "us", "our") to any person or entity booking such services ("Advertiser", "you", "your").

1.2 This Policy applies to all bookings made through our website, WhatsApp, email, phone or in person. It forms part of, and must be read together with, our Terms of Service and Privacy Policy. If this Policy conflicts with a written agreement signed by both parties, the signed agreement prevails.

1.3 By confirming a booking or making any payment, you confirm that you have read, understood and accepted this Policy.`],["2. Definitions",`2.1 "Campaign" means the display of your Advertisement on Adsrow's digital screen network under a confirmed Plan.

2.2 "Advertisement" or "Creative" means the image, video or other content supplied by you, or produced by Adsrow for you, for display.

2.3 "Plan" means the package booked by you, including Try It, Neighbourhood, Dine-Out, Fitness, City or any custom plan, together with its duration, locations and price.

2.4 "Booking Confirmation" means the summary of your Plan sent by Adsrow on WhatsApp or by email, stating the Plan, locations, Start Date, duration and amount payable.

2.5 "Start Date" means the date on which the Campaign is scheduled to begin, as stated in the Booking Confirmation.

2.6 "Committed Plan" means a Plan booked for 3 or 6 months at a discounted rate.

2.7 "Contracted Plays" means the number of times the Advertisement is scheduled to play during the Campaign under the Plan.

2.8 "Proof-of-Play Report" means the system-generated report issued by Adsrow recording the plays of the Advertisement.

2.9 "Working Day" means any day other than a Sunday or a public holiday in Andhra Pradesh.`],["3. Bookings and payment",`3.1 A booking is confirmed only when (a) Adsrow has issued a Booking Confirmation, and (b) the payment due has been received in full through the payment link or method provided by Adsrow.

3.2 All prices are exclusive of Goods and Services Tax ("GST") and other applicable taxes, which are charged additionally at the prevailing rate.

3.3 Plans are billed monthly in advance. For Committed Plans paid through UPI AutoPay, e-mandate or standing instruction, you authorise Adsrow, through its payment service provider, to collect each monthly instalment on its due date.

3.4 Adsrow never asks for your card number, CVV, UPI PIN or OTP on WhatsApp, phone or email. Pay only through the secure link sent by Adsrow's verified business account.`],["4. Cancellation before the Start Date",`4.1 48 hours or more before the Start Date: you may cancel by written notice (see Clause 12). You will receive a refund of 100% of the amount paid. If Adsrow has started producing a Creative for you, the design charge of ₹[●], as stated in the Booking Confirmation, will be deducted.

4.2 Less than 48 hours before the Start Date: you may cancel by written notice. You may choose either:
(a) a refund of the amount paid minus a cancellation charge of 10% of the first month's Plan value (excluding GST), or
(b) a full credit of the amount paid, usable against any Plan within 60 days of the cancellation date. Unused credit lapses after this period and cannot be converted to cash.

4.3 Rescheduling: you may postpone the Start Date once, by up to 30 days, at no charge, if you request it at least 48 hours before the original Start Date and inventory is available. A rescheduled booking cannot later be cancelled under Clause 4.1 within 48 hours of the new Start Date.`],["5. Content review and rejection",`5.1 All Advertisements are reviewed before display to make sure they comply with applicable law, including the Advertising Standards Council of India (ASCI) Code, and are suitable for family and public spaces, including residential communities, restaurants and fitness centres. Adsrow's decision on suitability is final, but will be made reasonably and in good faith.

5.2 If Adsrow rejects an Advertisement, it will explain why and allow you to submit a revised Advertisement. If you choose not to revise it, or the revision is also rejected, you will receive a refund of 100% of the amount paid for the Campaign. The design charge is deducted only if Adsrow produced the rejected Creative from content or claims you supplied.

5.3 Adsrow may stop displaying an Advertisement at any time, without refund, if it is found to contain or promote:
(a) false, misleading or unsubstantiated claims;
(b) content that infringes any third party's intellectual property, privacy or publicity rights;
(c) content that violates any law, or any direction of a court or authority; or
(d) content that is obscene, defamatory, hateful or otherwise unsuitable for the venues.`],["6. Cancellation after the Campaign has started",`6.1 Display time that has already passed cannot be recovered or resold. No refund is payable for any part of a Campaign already delivered.

6.2 For monthly Plans (including Try It), you may stop the Plan at any time. It will end on the last day of the month you have paid for, and no further payments will be collected. Unused days in that paid month are not refunded, except as provided in Clauses 7 and 9.`],["7. Delivery commitment and make-goods",`7.1 Adsrow issues a Proof-of-Play Report for every Campaign. That report is the primary record of delivery.

7.2 If, for reasons within Adsrow's reasonable control (including screen malfunction, scheduling error or connectivity failure on Adsrow's systems), the Advertisement receives less than 90% of its Contracted Plays in any billing month, you may choose either:
(a) make-good plays: additional plays or days, equal to or greater than the shortfall, at comparable venues and at no additional cost; or
(b) a pro-rata refund of the Plan value for that month corresponding to the shortfall in plays.

7.3 If a venue withdraws or relocates a screen during your Campaign, Adsrow will move your Advertisement to a venue of comparable audience and category. If no comparable venue is available, Adsrow will refund the value of the remaining days at the affected venue, on a pro-rata basis.

7.4 Claims under this Clause must be raised within 15 days from the end of the relevant billing month.`],["8. Committed Plans (3 or 6 months)",`8.1 Committed Plans are priced at a discount (10% for 3 months; 15% for 6 months) in exchange for your commitment to the full term.

8.2 You may end a Committed Plan early by giving at least 7 days' written notice before the next billing date. Adsrow will cancel your recurring payment mandate, and no further instalments will be collected.

8.3 On early termination, the months already used will be recalculated at the standard monthly rate, and the difference between that amount and the discounted amount you paid will become payable as an early termination adjustment. Adsrow will issue an invoice for this adjustment, payable within 7 days.

[Alternative 8.3, if you prefer not to collect money after cancellation: "On early termination, no further amount shall be payable by the Advertiser, and amounts already paid for months used shall not be refunded."]

8.4 Adsrow will send a pre-debit notification before each recurring debit, as required by the Reserve Bank of India's rules on recurring payments. You may need to authenticate certain debits, such as higher-value instalments, as required by those rules or by your bank.

8.5 If a recurring debit fails, Adsrow will notify you and give a payment link. If payment is not received within 3 Working Days of the due date, Adsrow may pause the Campaign until payment is received. The paused days will not be added back to the Plan term.`],["9. Events outside Adsrow's control (force majeure)",`9.1 Adsrow is not liable for any failure or delay caused by events beyond its reasonable control. These include power outages not caused by Adsrow, venue closures, natural disasters, epidemics, riots, strikes, internet or telecom disruption, and orders of any government or authority.

9.2 In such events, Adsrow will, at its option, extend the Campaign by the number of days affected or issue a credit of equal value usable within 90 days. If an event continues for more than 15 consecutive days, either party may terminate the affected Plan, and Adsrow will refund the value of the undelivered portion on a pro-rata basis.`],["10. Non-refundable items",`The following are not refundable, except where this Policy expressly says otherwise:
(a) design or production charges for any Creative that you have approved;
(b) add-on services already performed, including video production;
(c) Campaign days already delivered;
(d) credits that have lapsed under Clause 4.2(b) or Clause 9.2; and
(e) amounts relating to Advertisements removed under Clause 5.3.`],["11. Refund process and timelines",`11.1 Refunds approved under this Policy will be initiated within 7 Working Days of approval and made only to the original payment method (UPI, card, net banking or bank account). Refunds will not be paid in cash or to a third-party account.

11.2 After the refund is initiated, the time it takes to reach your account depends on your bank or payment provider, and is typically 5–10 Working Days.

11.3 For every refund, Adsrow will issue a GST credit note in accordance with the Central Goods and Services Tax Act, 2017. Where applicable, the GST charged on the refunded value will be refunded or adjusted on the credit note.

11.4 Payment gateway or processing charges will not be deducted from any refund made under this Policy.

11.5 Adsrow may withhold a refund if it reasonably suspects fraud, misuse of the Try It offer, or a payment made using an instrument the payer is not authorised to use.`],["12. How to cancel or request a refund",`12.1 Requests must be made in writing, quoting your booking reference, through either:
WhatsApp: +91 83746 22055 (Adsrow's verified business account), or
Email: [support email]

12.2 Adsrow will acknowledge your request within 1 Working Day and communicate its decision within 5 Working Days.

12.3 The time of a cancellation is the time Adsrow receives your written request.`],["13. Chargebacks","If you have a concern about a payment, please contact Adsrow first so it can be resolved quickly. If a chargeback or payment dispute is raised for an amount that is not refundable under this Policy, Adsrow may suspend the Campaign and provide the Booking Confirmation, Proof-of-Play Reports and communication records to the bank or payment provider."],["14. Special offers",`14.1 The Try It plan (₹99 per day) is available once per business, as identified by GSTIN, business name, phone number or premises. Clauses 4, 5, 7 and 9 apply to it in full.

14.2 Promotional prices, discounts or credits may carry additional terms, which will be stated at the time of the offer. If those terms conflict with this Policy, the offer's terms prevail.`],["15. Grievance redressal",`15.1 For any complaint about this Policy or our services, contact our Grievance Officer:
Name: [●]
Designation: [●]
Email: [grievance email]
Phone: [●]
Address: [registered office address]

15.2 The Grievance Officer will acknowledge complaints within 48 hours and resolve them within one month of receipt.`],["16. Changes to this Policy",'Adsrow may update this Policy from time to time. The updated Policy will be published on our website with a revised "Last updated" date. Changes will not apply to bookings already confirmed before the change, unless you agree otherwise.'],["17. Governing law and jurisdiction",`17.1 This Policy is governed by the laws of India.

17.2 Subject to Clause 17.3, the courts at Vijayawada, Andhra Pradesh, shall have exclusive jurisdiction over any dispute arising out of this Policy.

17.3 Nothing in this Policy limits any right you may have as a consumer under the Consumer Protection Act, 2019, including the right to approach a Consumer Commission with appropriate jurisdiction.`],["18. Severability","If any provision of this Policy is held invalid or unenforceable, the remaining provisions will continue in full force and effect."],["Drafting notes (remove before publishing)",`Clause 8.3 is the one real business choice. The main text takes back the discount on early exit; the alternative in italics is simpler and friendlier for small advertisers. Pick one and delete the other.

Grievance Officer (Clause 15): India's E-Commerce Rules require online sellers to name one, so keep this section if you take bookings online.

Clause 17.3 is deliberate. Consumers can't be stopped from going to a consumer commission, so trying to exclude that right would make the jurisdiction clause weaker, not stronger.

Where to link the policy: the website footer, the packages page, the WhatsApp plan summary before "Confirm & pay", and your payment provider's dashboard.

Fill in all [square bracket] items and have an Indian advocate or CA review the final text.`]],g=[["1. Who we are",`1.1 Adsrow Media Network Private Limited ("Adsrow", "we", "us", "our") runs a network of digital advertising screens at residential communities, restaurants and cafés, fitness centres and commercial spaces.

1.2 For the personal data described in this Privacy Policy, Adsrow is the Data Fiduciary under the Digital Personal Data Protection Act, 2023 ("DPDP Act"). This means we decide why and how your personal data is processed.

1.3 This Policy explains what personal data we collect, why we collect it, who we share it with, and the rights you have. It forms part of our Terms of Service.`],["2. Who this Policy covers",`This Policy applies to personal data of:
Advertisers and prospective advertisers: people who contact us, book a Plan or use our services;
Venue Partners: owners, managers and association members of venues that host or enquire about our screens;
Website visitors: people who browse [domain]; and
People who scan a QR code shown on our screens.

This Policy does not cover the websites, apps or WhatsApp accounts of advertisers whose Advertisements appear on our screens. Their own privacy policies apply.`],["3. Personal data we collect","We only collect what we need for the purposes in Section 5. Please do not send us sensitive information, such as health or financial account details, that we have not asked for."],["4. Our screens and members of the public",`4.1 Our screens only display content. [Our screens do not have cameras, microphones or sensors that identify individuals, and we do not use facial recognition or collect personal data from people who watch them.]

4.2 Audience figures we share with advertisers, such as people reached per day, are estimates based on venue footfall information provided by Venue Partners and other aggregate data. They do not identify any individual.

4.3 Our team may photograph screens at venues to prove that an Advertisement was displayed. We take care to avoid capturing identifiable people, and blur or crop anyone who appears by accident before sharing the photograph.`],["5. How we use personal data, and why","Where we rely on consent, we will ask for it clearly, and you may withdraw it as easily as you gave it. Withdrawal does not affect processing that took place before it."],["6. Who we share personal data with",`6.1 We do not sell your personal data. We share it only as needed for the purposes in Section 5, with:

6.2 Service providers that process personal data for us (Data Processors) do so under contracts that require them to protect it and use it only on our instructions.`],["7. Transfers outside India","Some of our service providers, such as WhatsApp, hosting and email providers, may store or process data on servers outside India. Such transfers are made as permitted by the DPDP Act and any restrictions notified by the Government of India, and the providers are required to protect the data to the standard described in this Policy."],["8. How long we keep personal data","When data is no longer needed, we delete it or make it anonymous, unless the law requires us to keep it longer."],["9. How we protect personal data",`9.1 We use reasonable security safeguards, including access controls limited to staff who need the data, password-protected and two-factor-protected accounts, encrypted connections (HTTPS) on the Website, and payment processing only through our provider's secure pages.

9.2 No system is completely secure. If a personal data breach occurs, we will inform the Data Protection Board of India and affected individuals as required by the DPDP Act, and take steps to limit its impact.`],["10. Cookies and similar technologies",`10.1 The Website uses:
Essential cookies, needed for the Website to work; and
Analytics cookies [e.g. Google Analytics], which help us understand visits and button clicks such as "Choose on WhatsApp". These are used only if you accept them in our cookie banner.

10.2 You can change your cookie choice at any time through the [Cookie settings] link in the Website footer, or by clearing cookies in your browser. Blocking essential cookies may affect how the Website works.`],["11. Marketing messages",`11.1 We will send promotional messages, such as new offers or packages, only if you have agreed to receive them.

11.2 You can opt out at any time by replying STOP on WhatsApp, using the unsubscribe link in an email, or contacting us (Section 17). You will still receive service messages about any active booking, payment or Campaign.`],["12. Your rights",`12.1 Under the DPDP Act, you (as a Data Principal) have the right to:
Access: get a summary of the personal data we hold about you, how we process it, and who we have shared it with;
Correct and update: have inaccurate or incomplete data corrected, completed or updated;
Erase: have your data deleted when it is no longer needed for the purpose it was collected for, unless the law requires us to keep it;
Withdraw consent: for any processing based on consent, at any time;
Grievance redressal: have your complaint handled by our Grievance Officer (Section 14); and
Nominate: name another person to exercise these rights on your behalf in the event of your death or incapacity.

12.2 To use these rights, contact us as set out in Section 17. We may need to verify your identity before acting on a request. We will respond within the time limits set by the DPDP Act and its rules, and in any case within [30] days.

12.3 Please give us accurate information and do not make false or frivolous complaints, as the DPDP Act also places these duties on Data Principals.`],["13. Children","Our services are meant for businesses and adults. We do not knowingly collect personal data of anyone under 18. If you believe a child has shared personal data with us, contact us and we will delete it."],["14. Grievance Officer",`For any question or complaint about how we handle personal data, contact:
Name: [●]
Designation: Grievance Officer
Email: [privacy or grievance email]
Phone: [●]
Address: [registered office address], Vijayawada, Andhra Pradesh

We will acknowledge your complaint within 48 hours and aim to resolve it within [30] days.`],["15. Data Protection Board of India","If you are not satisfied with our response, you may file a complaint with the Data Protection Board of India once you have first raised it with our Grievance Officer, as provided under the DPDP Act."],["16. Changes to this Policy",'We may update this Policy from time to time. The updated Policy will be published on the Website with a revised "Last updated" date. If a change significantly affects how we use your personal data, we will notify you on WhatsApp or by email, and ask for fresh consent where required.'],["17. Contact us","Adsrow Media Network Private Limited, [registered office address], Vijayawada, Andhra Pradesh · WhatsApp: +91 83746 22055 · Email: [privacy email]"],["Drafting notes (remove before publishing)",`Clause 4.1 must be true. Confirm that your screens and media players have no cameras, microphones or audience-sensing features. If you add audience measurement later, this Policy must change before you switch it on.

Section 6: replace the bracketed examples with the providers you actually use (WhatsApp provider, payment provider, hosting, analytics, email).

Section 8: confirm the retention periods with your CA, especially for invoice and tax records.

Section 10: add a cookie banner to the Website that loads analytics only after the visitor accepts, so that the Policy matches what the site does.

DPDP Act timing: the DPDP Act's rules are being brought into force in phases. Check with your advocate which obligations, including breach reporting and consent manager rules, apply to Adsrow today, and keep the existing IT Act (Information Technology Act, 2000) obligations until they are replaced.

Use the same Grievance Officer in this Policy, the Terms of Service and the Refund & Cancellation Policy.

Fill in all [square bracket] items and have an Indian advocate review the final text.`]];function s(a){return a.toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"")}function o({title:a,documentDate:d,sections:n}){return m.useEffect(()=>{document.title=`${a} | Adsrow`;let t=document.querySelector('meta[name="robots"]');return t||(t=document.createElement("meta"),t.name="robots",document.head.appendChild(t)),t.content="noindex, nofollow",()=>{document.title="Adsrow | Local Digital Advertising"}},[a]),e.jsx("main",{className:"legal-page section",children:e.jsxs("div",{className:"container legal-container",children:[e.jsx(y,{to:"/",className:"legal-back",children:"← Back to Adsrow"}),e.jsx("h1",{className:"page-title",children:a}),e.jsxs("p",{className:"legal-meta",children:["Adsrow Media Network Private Limited · ",d]}),e.jsxs("nav",{className:"legal-toc","aria-label":`${a} contents`,children:[e.jsx("strong",{children:"Contents"}),e.jsx("ol",{children:n.map(([t])=>e.jsx("li",{children:e.jsx("a",{href:`#${s(t)}`,children:t})},t))})]}),e.jsx("div",{className:"legal-content",children:n.map(([t,l])=>e.jsxs("section",{className:"legal-section",id:s(t),children:[e.jsx("h2",{children:t}),l.split(/\n\n+/).map((c,u)=>{const i=c.split(`
`);return e.jsx("p",{children:i.map((h,r)=>e.jsxs("span",{children:[h,r<i.length-1&&e.jsx("br",{})]},r))},`${t}-${u}`)})]},t))})]})})}function b(){return e.jsx(o,{title:"Terms of Service",documentDate:"Effective date: [●] · Last updated: [●]",sections:p})}function v(){return e.jsx(o,{title:"Refund and Cancellation Policy",documentDate:"Effective date: [●] · Last updated: [●]",sections:f})}function A(){return e.jsx(o,{title:"Privacy Policy",documentDate:"Effective date: [●] · Last updated: [●]",sections:g})}export{A as PrivacyPage,v as RefundPolicyPage,b as TermsPage,g as privacySections,f as refundSections,p as termsSections};
